package com.explora.places.service;

public interface PlacesConnectorService {
  
	String connect(String url);
}

